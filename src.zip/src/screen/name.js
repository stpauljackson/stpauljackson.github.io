import './name.css'

export default function Name() {
    return(
        <div className="name">
            <div className="namecontainer">
            <h1>Sushant Kumar</h1>
            <h2>Software Engineer</h2>
            </div>
        </div>
    )
}